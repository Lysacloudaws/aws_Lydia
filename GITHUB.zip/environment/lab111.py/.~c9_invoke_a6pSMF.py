print("hello,world")
myFruitList = ["apple", "banana", "cherry"]




person = {name: "Lydia",age: 29}

pri
