#Tuples





person = {name: "Lydia",age: 29}

pri
