print("Python has three numeric types: int, float, and complex")


myValue=1
print(myValue)

print(str(myValue) + " is of the data type " + str(type(myValue)))

myValue=3.14
print(myValue)

print(type(myValue))
print(str(myValue) + " is of the data type " + str(type(myValue))) #this gives the datatypes of the values

myValue=5j
print(myValue)
print(type(myValue))
print(str(myValue) + " is of the data type " + str(type(myValue)))

myvalue=5j
print(myvalue)
print(type(myvalue))
print(str(myvalue) + "is of the data type" + str(type(myvalue)))

myvalue=True
print(myvalue)
print(type(myvalue))
print(str(myValue) + " is of the data type " + str(type(myValue)))

myvalue=False
print(myvalue)
print(type(myvalue))
print(str(myValue) + " is of the data type " + str(type(myValue)))
